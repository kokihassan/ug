<?php
// api/menu.php - Menu CRUD API
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {

    // ─── PUBLIC: Get full menu (for bot & website) ───────────────
    case 'GET:public':
        $branchId = $_GET['branch_id'] ?? null;
        $db = getDB();

        $cats = $db->query("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order ASC")->fetchAll();
        
        foreach ($cats as &$cat) {
            $sql = "SELECT m.*, 
                COALESCE(iba.is_available, m.is_available) as branch_available,
                COALESCE(iba.override_price, m.price) as final_price
                FROM menu_items m
                LEFT JOIN item_branch_availability iba 
                    ON m.id = iba.item_id AND iba.branch_id = :bid
                WHERE m.category_id = :cid AND m.is_available = 1
                ORDER BY m.sort_order ASC";
            $stmt = $db->prepare($sql);
            $stmt->execute([':cid' => $cat['id'], ':bid' => $branchId]);
            $items = $stmt->fetchAll();
            
            foreach ($items as &$item) {
                // Get extras
                $extras = $db->prepare("SELECT * FROM item_extras WHERE item_id=? AND is_available=1 ORDER BY sort_order");
                $extras->execute([$item['id']]);
                $item['extras'] = $extras->fetchAll();
                
                // Get sizes
                $sizes = $db->prepare("SELECT * FROM item_sizes WHERE item_id=? ORDER BY sort_order");
                $sizes->execute([$item['id']]);
                $item['sizes'] = $sizes->fetchAll();
            }
            $cat['items'] = $items;
        }
        success($cats);

    // ─── PUBLIC: Get menu for bot (compact format) ────────────────
    case 'GET:bot-menu':
        $branchId = intval($_GET['branch_id'] ?? 1);
        $db = getDB();
        
        $sql = "SELECT c.name as category, m.id, m.name, m.description, m.price,
                m.preparation_time_minutes, m.is_featured, m.is_new, m.image,
                COALESCE(iba.is_available, 1) as available,
                COALESCE(iba.override_price, m.price) as final_price
                FROM menu_items m
                JOIN categories c ON m.category_id = c.id
                LEFT JOIN item_branch_availability iba ON m.id=iba.item_id AND iba.branch_id=:bid
                WHERE m.is_available=1 AND c.is_active=1
                ORDER BY c.sort_order, m.sort_order";
        $stmt = $db->prepare($sql);
        $stmt->execute([':bid' => $branchId]);
        success($stmt->fetchAll());

    // ─── ADMIN: Get all categories ────────────────────────────────
    case 'GET:categories':
        requireAuth();
        $db = getDB();
        $cats = $db->query("SELECT * FROM categories ORDER BY sort_order ASC")->fetchAll();
        success($cats);

    // ─── ADMIN: Create category ───────────────────────────────────
    case 'POST:categories':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        
        $image = null;
        if (!empty($_FILES['image'])) $image = uploadImage($_FILES['image'], 'categories');
        
        $stmt = $db->prepare("INSERT INTO categories (name, name_en, description, image, icon, sort_order, is_active) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$data['name'], $data['name_en']??null, $data['description']??null, $image, $data['icon']??null, $data['sort_order']??0, $data['is_active']??1]);
        success(['id' => $db->lastInsertId()], 'تم إضافة القسم', 201);

    // ─── ADMIN: Update category ───────────────────────────────────
    case 'PUT:categories':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("UPDATE categories SET name=?, name_en=?, description=?, icon=?, sort_order=?, is_active=?, updated_at=NOW() WHERE id=?");
        $stmt->execute([$data['name'], $data['name_en']??null, $data['description']??null, $data['icon']??null, $data['sort_order']??0, $data['is_active']??1, $id]);
        success([], 'تم التحديث');

    // ─── ADMIN: Get all items ─────────────────────────────────────
    case 'GET:items':
        requireAuth();
        $db = getDB();
        $catId = $_GET['category_id'] ?? null;
        $search = $_GET['search'] ?? null;
        $sql = "SELECT m.*, c.name as category_name FROM menu_items m JOIN categories c ON m.category_id=c.id WHERE 1=1";
        $params = [];
        if ($catId) { $sql .= " AND m.category_id=?"; $params[] = $catId; }
        if ($search) { $sql .= " AND m.name LIKE ?"; $params[] = "%$search%"; }
        $sql .= " ORDER BY c.sort_order, m.sort_order";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        success($stmt->fetchAll());

    // ─── ADMIN: Create item ───────────────────────────────────────
    case 'POST:items':
        requireAuth();
        $data = $_POST ?: json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        
        $image = null;
        if (!empty($_FILES['image'])) $image = uploadImage($_FILES['image'], 'items');
        
        $stmt = $db->prepare("INSERT INTO menu_items 
            (category_id, name, name_en, description, price, image, preparation_time_minutes,
             calories, is_available, is_featured, is_new, is_spicy, is_vegetarian, sort_order)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $data['category_id'], $data['name'], $data['name_en']??null,
            $data['description']??null, $data['price'], $image,
            $data['preparation_time_minutes']??15, $data['calories']??null,
            $data['is_available']??1, $data['is_featured']??0,
            $data['is_new']??0, $data['is_spicy']??0,
            $data['is_vegetarian']??0, $data['sort_order']??0
        ]);
        $newId = $db->lastInsertId();
        
        // Create branch availability records for all branches
        $branches = $db->query("SELECT id FROM branches")->fetchAll();
        foreach ($branches as $branch) {
            $db->prepare("INSERT INTO item_branch_availability (item_id, branch_id, is_available) VALUES (?,?,1)")
               ->execute([$newId, $branch['id']]);
        }
        
        success(['id' => $newId], 'تم إضافة الصنف', 201);

    // ─── ADMIN: Update item ───────────────────────────────────────
    case 'PUT:items':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        
        $stmt = $db->prepare("UPDATE menu_items SET 
            category_id=?, name=?, name_en=?, description=?, price=?,
            preparation_time_minutes=?, calories=?, is_available=?, 
            is_featured=?, is_new=?, is_spicy=?, is_vegetarian=?, 
            sort_order=?, updated_at=NOW() WHERE id=?");
        $stmt->execute([
            $data['category_id'], $data['name'], $data['name_en']??null,
            $data['description']??null, $data['price'],
            $data['preparation_time_minutes']??15, $data['calories']??null,
            $data['is_available']??1, $data['is_featured']??0,
            $data['is_new']??0, $data['is_spicy']??0,
            $data['is_vegetarian']??0, $data['sort_order']??0, $id
        ]);
        success([], 'تم التحديث');

    // ─── ADMIN: Upload item image ─────────────────────────────────
    case 'POST:upload-image':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id || empty($_FILES['image'])) error('Missing data');
        $imageUrl = uploadImage($_FILES['image'], 'items');
        if (!$imageUrl) error('فشل رفع الصورة');
        $db = getDB();
        $db->prepare("UPDATE menu_items SET image=? WHERE id=?")->execute([$imageUrl, $id]);
        success(['image' => $imageUrl], 'تم رفع الصورة');

    // ─── ADMIN: Toggle branch availability ────────────────────────
    case 'PUT:branch-availability':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO item_branch_availability (item_id, branch_id, is_available) 
            VALUES (?,?,?) ON DUPLICATE KEY UPDATE is_available=?");
        $stmt->execute([$data['item_id'], $data['branch_id'], $data['is_available'], $data['is_available']]);
        success([], 'تم التحديث');

    // ─── ADMIN: Excel Import ──────────────────────────────────────
    case 'POST:import-excel':
        requireAuth();
        if (empty($_FILES['file'])) error('لم يتم رفع ملف');
        
        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['csv', 'xlsx'])) error('يجب أن يكون الملف CSV أو XLSX');
        
        // Move uploaded file
        $tmpPath = sys_get_temp_dir() . '/' . uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['file']['tmp_name'], $tmpPath);
        
        $rows = [];
        if ($ext === 'csv') {
            $handle = fopen($tmpPath, 'r');
            $headers = fgetcsv($handle); // skip header row
            while (($row = fgetcsv($handle)) !== false) {
                if (count($row) >= 4) {
                    $rows[] = [
                        'category'    => trim($row[0]),
                        'name'        => trim($row[1]),
                        'description' => trim($row[2] ?? ''),
                        'price'       => floatval($row[3]),
                        'prep_time'   => intval($row[4] ?? 15),
                        'available'   => strtolower(trim($row[5] ?? 'نعم')) === 'نعم' ? 1 : 0,
                    ];
                }
            }
            fclose($handle);
        }
        
        $db = getDB();
        $imported = 0;
        $errors = [];
        
        foreach ($rows as $i => $row) {
            if (empty($row['name']) || empty($row['category']) || $row['price'] <= 0) {
                $errors[] = "صف " . ($i + 2) . ": بيانات ناقصة";
                continue;
            }
            
            // Find or create category
            $stmt = $db->prepare("SELECT id FROM categories WHERE name=?");
            $stmt->execute([$row['category']]);
            $cat = $stmt->fetch();
            
            if (!$cat) {
                $db->prepare("INSERT INTO categories (name, is_active) VALUES (?,1)")->execute([$row['category']]);
                $catId = $db->lastInsertId();
            } else {
                $catId = $cat['id'];
            }
            
            // Insert item
            $stmt = $db->prepare("INSERT INTO menu_items 
                (category_id, name, description, price, preparation_time_minutes, is_available)
                VALUES (?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE price=VALUES(price), description=VALUES(description)");
            $stmt->execute([$catId, $row['name'], $row['description'], $row['price'], $row['prep_time'], $row['available']]);
            $imported++;
        }
        
        unlink($tmpPath);
        success(['imported' => $imported, 'errors' => $errors], "تم استيراد $imported صنف");

    // ─── Download Excel Template (no auth - static file) ─────────
    case 'GET:excel-template':
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="menu_template.csv"');
        echo "\xEF\xBB\xBF"; // UTF-8 BOM for Arabic
        echo "القسم,اسم الصنف,الوصف,السعر,وقت التحضير (دقيقة),متاح (نعم/لا)\n";
        echo "مشويات,كباب مشوي,كباب طازج مشوي على الفحم,45,20,نعم\n";
        echo "مشويات,كفتة,كفتة لحم بالتوابل,40,15,نعم\n";
        echo "مشروبات,عصير برتقال,عصير برتقال طازج,15,5,نعم\n";
        exit();

    default:
        error('Action not found', 404);
}
